<?php
/**
 * Generate a quant table
 */
?>
<div class="quant-table" style="width: <?php print $width; ?>px;">
  <h3><?php print $title; ?></h3>
  <?php print $table; ?>
</div>
