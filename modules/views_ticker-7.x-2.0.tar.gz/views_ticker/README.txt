
This module provides new styles for Views module to display news tickers.

Available ticker styles:

- Fade:
  Smooth transition between news titles, light and JQuery-powered.
- BBC Style:
  Display news titles typewriter-like (Only links)
  Uses a JQuery plugin by Bryan Gullan
- Scroller
  Display horizontally or vertically scrolling news titles.
  Uses JScroller by Markus Bordihn
  
Put in the views tickers only short fields!


This module also provides some default views, try them enabling relative blocks in admin/build/block.
There are themeable functions, take a look at views_ticker.module

 


