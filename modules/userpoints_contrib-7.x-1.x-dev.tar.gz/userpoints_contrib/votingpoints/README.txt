
This is a very small module that adds a "rules" event for the votingapi "when user votes", and points are awarded accordingly.

The file votingpoints.rules_sample.inc provides a sample of what this module can do.

For other ways of awarding points for votes, see this project as well
http://drupal.org/project/userpoints_votingapi
