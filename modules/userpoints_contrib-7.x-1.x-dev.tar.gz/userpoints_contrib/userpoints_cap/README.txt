Author: Mike Smullin http://mikesmullin.com

INSTALLATION

1. Extract to the site/all/modules
2. Enable in Administer > Modules (admin/modules).
3. Configure in Administer > User Points settings (admin/config/people/userpoints/settings).

That's it!
