
Welcome to Extra Voting Forms!

This module gives you easy-to-use, and yet powerful, voting forms. It derives
from the now defunct simple_karma.module.

Some features:

- Javascript voting; however, the module works 1000% even if the
user doesn't have Javascript

- Abuse control. The module allows you to limit users on how many points
they can give. The admin can also decide on how many different
comments/nodes a user can vote on

- Bonus voting powers to people with specific permissions. When a user has them
(because they are associated to a role, for example), then the user can give/take
more votes on each click.

- Everything is configurable from the admin interface

- Themable. The voting forms can look however you like. Two examples
are provided.

- Ability to put the forms in the link section of the comment/node
or anywhere in the comment template (by hand)

Enjoy!

