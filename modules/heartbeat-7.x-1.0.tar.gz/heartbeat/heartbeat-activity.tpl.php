<div class="<?php print $classes;?>"<?php print $attributes; ?>>
  <?php print render($content); ?>
</div>