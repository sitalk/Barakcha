=== FLAG FOLLOW ===
 
Installation/Initial configurations

  1) Go to 'admin/modules' page.
 
  2) Enable Heartbeat, Flags, Rules and Flag Follow module.

  3) Go to 'admin/people/permissions' page.
   
  4) Enable 'View activity' and 'View activity in Favorites' permissions
     for authenticated users under 'Heartbeat activity' head.

  5) Enable 'View user profiles' permission for authenticated users under 
     'User' head.
  
  6) Go to a user profile page and start 'follow' that user.
 
  7) View your followed users activities under 'Favorites' tab on your
     profile page.