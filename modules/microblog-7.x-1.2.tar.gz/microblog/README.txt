
Microblogging for Drupal module

Requires Drupal 7.x, PHP 5

Tested on Drupal 7.0-BETA3, PHP 5.2.11, MySQL 5.1.45

todo:
- Feeds (revise standard node feed to not include body, etc)
- Set Favorites? Would also need tab to view favorites
- CLIENT API: twitter api equivalency